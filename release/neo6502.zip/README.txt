Release Notes
-------------

This is a more advanced version, save/load works, the NeoBasic is implemented (no sound/graphics yet) and Apple 1 BASIC
and Fig FORTH have been removed.

BASIC is booted via 'N' or 800R. There is a short documentation as a pdf/odt file available and some sample code in the
samples

All suggestions are welcome.

Paul Robson.
paul@robsons.org.uk
28 Dec 2023

*****************
*** IMPORTANT ***
*****************

If you are using the SD Card storage board made by Olimex, it requires the switches 2-4 on the B boards to be OFF. The 
board is shipped with all switches set to 'on' (Switch 1 is the on board beeper). 

Without this change the SD Card will not work (see the board manual page 12).

