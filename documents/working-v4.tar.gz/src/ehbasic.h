// ehbasic.h

#ifndef _EHBASIC_h
#define _EHBASIC_h

#include "Arduino.h"

#define EHBASIC_START 0xA000
#define EHBASIC_SIZE  0x2828

extern const uint8_t ehbasic_bin[];
#endif

