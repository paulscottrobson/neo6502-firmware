// 
// Author: Rien Matthijsse
// 

#ifndef _MON_EXT_h
#define _MON_EXT_h

#include "Arduino.h"

#define MON_EXT_START 0xF000
#define MON_EXT_SIZE  0x0359

extern const uint8_t mon_ext_bin[];

#endif

