// 
// Author: Rien Matthijsse
// 

#ifndef _MSBASIC_h
#define _MSBASIC_h

#include "Arduino.h"

#define MSBASIC_START 0xA000
#define MSBASIC_SIZE  0x207A

extern const uint8_t msbasic_bin[];

#endif

