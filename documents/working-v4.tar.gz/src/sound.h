// sound.h

#ifndef _SOUND_h
#define _SOUND_h

#include "Arduino.h"
#include "pins.h"

void initSound();
void SoundReset();
void SoundSetDuration(uint8_t);
void SoundSetNote(uint8_t);
boolean SoundPushTheNote();
uint8_t SoundQueueIsEmpty();
uint8_t SoundQueueIsFull();

#endif

