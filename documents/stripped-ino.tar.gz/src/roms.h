// roms.h

#ifndef _ROMS_h
#define _ROMS_h

#include "Arduino.h"

bool loadROMS();
#endif

